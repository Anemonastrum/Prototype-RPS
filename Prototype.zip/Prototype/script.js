document.getElementById("sidebar").style.height = "100vh";
const toggleBtn = document.getElementById("toggle-btn");
const sidebar = document.getElementById("sidebar");
const content = document.getElementById("content");

toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("collapsed");
  content.classList.toggle("expanded");
});




function ngeprint() {

  const content = document.getElementById('content').innerHTML
  const iframe = document.createElement('iframe')
  iframe.id = 'myDiv'
  
  function addCssLinkToDiv(divId, cssUrl) {
    var divElement = document.getElementById(divId);
    
    if (divElement) {
      var linkElement = document.createElement('link');
      linkElement.rel = 'stylesheet';
      linkElement.href = cssUrl;
      divElement.appendChild(linkElement);
    }
  }

  addCssLinkToDiv('myDiv', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css');

  document.body.appendChild(iframe);
  var iframeWindow = iframe.contentWindow || iframe.contentDocument;
  iframeWindow.document.open();
  iframeWindow.document.write(content);
  iframeWindow.document.close();
  
  iframeWindow.print();
  
  iframe.parentNode.removeChild(iframe);
  console.log("gg")

}
